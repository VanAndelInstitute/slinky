## ---- echo=TRUE, eval=FALSE, message=F, warning=F------------------------
#  library(slinky)
#  sl <- Slinky$new() # assumes environment variable CLUE_API_KEY is set.
#  fda <- sl$fetch("rep_drugs", where_clause=list("status_source"=list(like = "FDA Orange"),
#                                                     "final_status"="Launched",
#                                                     "animal_only"="0",
#                                                     "in_cmap"=TRUE))
#  
#  
#  

## ---- echo=FALSE, message=F, warning=F-----------------------------------
library(slinky)
user_key <- content(httr::GET("https://api.clue.io/temp_api_key"), as="parsed")$user_key
sl <- Slinky$new(user_key)
fda <- sl$fetch("rep_drugs", where_clause=list("status_source"=list(like = "FDA Orange"),
                                                   "final_status"="Launched",
                                                   "animal_only"="0",
                                                   "in_cmap"=TRUE))




## ------------------------------------------------------------------------
fda_pert <- sl$fetch("sigs", 
                     fields = c("pert_desc", "distil_id"), 
                     where_clause=list("pert_type"="trt_cp", 
                                       "is_gold"=TRUE,
                                       "pert_iname"=list("inq"=fda$pert_iname)))

# expand the delimited distil_id values
unwrap <- function(x) {
  ids <- unlist(strsplit(x[1], split = "\\|"))
  res <- cbind(x[2], ids)
  colnames(res) <- c("pert_desc", "distil_id")
  return(res)
}

#inst_fda_gold <- unique(unlist(strsplit(fda_pert$distil_id, split = "\\|")))
inst_fda_gold <- do.call(rbind, apply(fda_pert, 1, unwrap))
rownames(inst_fda_gold) <- NULL


## ------------------------------------------------------------------------
l1000 <- sl$fetch("genes", fields=c("entrez_id", "gene_symbol"), where_clause=list("l1000_type" = "landmark"))


## ----eval=FALSE----------------------------------------------------------
#  gctx.file <- "~/lincs_data/GSE92742_Broad_LINCS_Level3_INF_mlr12k_n1319138x12328.gctx"
#  
#  ids <- sl$gctx.colnames(gctx.file)
#  col.ix <- which(ids %in% inst_fda_gold$distil_id)
#  ids <- ids[col.ix]
#  
#  genes <- sl$gctx.rownames(gctx.file)
#  row.ix <- which(genes %in% l1000$entrez_id) # it's the first 978 genes in the data matrix!
#  genes <- genes[row.ix]
#  
#  data <- sl$gctx.read(gctx.file, index = list(row.ix, col.ix))
#  rownames(data) <- genes
#  colnames(data) <- ids
#  saveRDS(data, compress="gzip", file="l1000_fda.rds")
#  

## ------------------------------------------------------------------------
  link <- "https://github.com/erikor/locket/raw/master/l1000_fda.rds"
  temp <- tempfile()
  download.file(link,temp,method = "curl", extra = "-L", quiet=TRUE)
  fda <- readRDS(temp)
  unlink(temp)

## ----eval=FALSE----------------------------------------------------------
#  cl <- makeCluster(8)
#  dmso_pert <- sl$fetch("profiles",
#                       fields = c("det_plate", "distil_id"),
#                       where_clause=list("pert_type"="ctl_vehicle",
#                                         "pert_id"="DMSO"), cl=cl)
#  stopCluster(cl)
#  
#  ids <- sl$gctx.colnames(gctx.file)
#  col.ix <- which(ids %in% dmso_pert$distil_id)
#  ids <- ids[col.ix]
#  
#  data <- sl$gctx.read(gctx.file, index = list(row.ix, col.ix))
#  rownames(data) <- genes
#  colnames(data) <- ids
#  
#  saveRDS(data, compress="gzip", file="l1000_dmso.rds")

## ------------------------------------------------------------------------
  link <- "https://github.com/erikor/locket/raw/master/l1000_dmso.rds"
  temp <- tempfile()
  download.file(link,temp,method = "curl", extra = "-L", quiet=TRUE)
  dmso <- readRDS(temp)
  unlink(temp)

## ---- eval=FALSE, echo=TRUE----------------------------------------------
#  library("doParallel")
#  plates <- gsub(":.*", "", colnames(dmso))
#  ctrl <- t(apply(dmso, 1, function(x) { tapply(x, INDEX = plates, mean)}))
#  
#  cl<-makeCluster(8)
#  registerDoParallel(cl)
#  zs <- foreach(i = 1:ncol(fda), .combine = cbind) %dopar% {
#    plate <- gsub(":.*", "", colnames(fda)[i])
#    fc <- fda[,i] / ctrl[,plate]
#    (fc - median(fc)) / mad(fc)
#  }
#  stopCluster(cl)
#  colnames(zs) <- colnames(fda)
#  rownames(zs) <- rownames(fda)
#  zs <- zs * 1000 # save space on github
#  saveRDS(zs, file="l1000_fda_zsvc_x1000.rds", compress="gzip")
#  

## ------------------------------------------------------------------------

zsvc <- system.file("extdata", "test_inst_zsvc_x1000.rds", package="slinky")
info <- system.file("extdata", "test_inst_info.rds", package="slinky")
data <- readRDS(zsvc) / 1000
up <- rownames(data)[order(data[,1], decreasing = TRUE)][1:25]
down <- rownames(data)[order(data[,1])][1:25]
cs <- sl$score(data, "ks", up=up, down=down)
xs <- sl$score(data, "xsum", up=up, down=down)
plot(cs, xs, pch=19)

