library(testthat)
library(clue)

test_check("clue")